import pygame
import os
import random

pygame.init()
size = width, height = 800, 600
screen = pygame.display.set_mode(size)

def load_image(name, colorkey = None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(name)
        if colorkey is not None:
            if colorkey is -1:
                colorkey = image.get_at((0, 0))
            image.set_colorkey(colorkey)
        image = image.convert_alpha()
        return image
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)

def draw(words,text_x1, text_y1,fnt, rect=False):
    font = pygame.font.Font('freesansbold.ttf', fnt)
    text = font.render(words, 1, (255, 255, 0))
    text_x = text_x1 - text.get_width() // 2
    text_y = text_y1 - text.get_height() // 2
    text_w = text.get_width()
    text_h = text.get_height()
    screen.blit(text, (text_x, text_y))
    if rect:
        pygame.draw.rect(screen, (255, 0, 0), (text_x - 10, text_y - 10, text_w + 20, text_h + 20), 1)     

class Sky(pygame.sprite.Sprite):
    image = load_image("sky.png")
    image = pygame.transform.scale(image, (width, height))
    def __init__(self):
        super().__init__(sky_sprites)
        self.image = Sky.image
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.bottom = height

class Court(pygame.sprite.Sprite):
    image = load_image("court.png")
    image = pygame.transform.scale(image, (width, height))
    def __init__(self):
        super().__init__(court_sprites)
        self.image = Court.image
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.bottom = height

class Mountain(pygame.sprite.Sprite):
    image = load_image("mountains.png",-1)
    image = pygame.transform.scale(image, (width, int(204 * width / 789) + 1))
    def __init__(self):
        super().__init__(mountain_sprites)
        self.image = Mountain.image
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.bottom = height
        
class Hoop(pygame.sprite.Sprite):
    image = load_image("bh.png")
    image = pygame.transform.scale(image, (int((width/12600)*1679), int((width/12600)*1588)))
    def __init__(self):
        super().__init__(hoop_sprites)
        self.image = Hoop.image
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = width//2 - int((width/12600)*1679)//2
        self.rect.y = height - int((width/12600)*1588)//2 - 100

class Landing(pygame.sprite.Sprite):
    image = load_image("bb.png")
    image = pygame.transform.scale(image, (int((width/4200)*355), int((width/4200)*361)))

    def __init__(self):
        super().__init__(all_sprites)
        self.image = Landing.image
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = random.randrange(width-int((width/4200)*355))
        self.rect.y = -int((width/4200)*361) - 50

    def update(self):
        if not pygame.sprite.collide_mask(self, hoop):
            if fps2 < 100:
                self.rect = self.rect.move(0, 3)
            elif fps2 < 200:
                self.rect = self.rect.move(0, 4)
            else:
                self.rect = self.rect.move(0, 5)
        elif pygame.sprite.collide_mask(self, hoop):
            all_sprites.remove(self)
            score_sprites.add(self)
        if self.rect.y > height:
            all_sprites.remove(self)
            j = 0
            for heart in hearts_sprites:
                j += 1
                if j == len(hearts_sprites):
                    hearts_sprites.remove(heart)

class Heart(pygame.sprite.Sprite):
    image = load_image("heart.png")
    image = pygame.transform.scale(image, (int((width/18900)*1111), int((width/18900)*1032)))

    def __init__(self, pos=None):
        if not pos:
            super().__init__(all_sprites)
        else:
            super().__init__(hearts_sprites)
        self.image = Heart.image
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        if not pos:
            self.rect.x = random.randrange(width-int((width/12600)*1111))
            self.rect.y = -int((width/12600)*1032) - 50
            self.k = 1
        else:
            self.rect.x = pos[0]
            self.rect.y = pos[1]
            self.k = 0

    def update(self):
        if self.k:
            if not pygame.sprite.collide_mask(self, hoop):
                if fps2 < 100:
                    self.rect = self.rect.move(0, 2)
                elif fps2 < 200:
                    self.rect = self.rect.move(0, 3)
                else:
                    self.rect = self.rect.move(0, 4)
            elif pygame.sprite.collide_mask(self, hoop):
                all_sprites.remove(self)
                Heart((len(hearts_sprites)*(int((width/18900)*1111) + 10),0))
            elif self.rect.y == height:
                all_sprites.remove(self)

class Label:
    def __init__(self, rect, text):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.bgcolor = pygame.Color("white")
        self.font_color = pygame.Color("black")
        self.font = pygame.font.Font('freesansbold.ttf', self.rect.height - 4)
        self.rendered_text = None
        self.rendered_rect = None


    def render(self, surface):
        surface.fill(self.bgcolor, self.rect)
        self.rendered_text = self.font.render(self.text, 1, self.font_color)
        self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 2, centery=self.rect.centery)
        surface.blit(self.rendered_text, self.rendered_rect)

class GUI:
    def __init__(self):
        self.elements = []

    def add_element(self, element):
        self.elements.append(element)

    def render(self, surface):
        for element in self.elements:
            render = getattr(element, "render", None)
            if callable(render):
                element.render(surface)                    

    def update(self):
        for element in self.elements:
            update = getattr(element, "update", None)
            if callable(update):
                element.update()

    def get_event(self, event):
        for element in self.elements:
            get_event = getattr(element, "get_event", None)
            if callable(get_event):
                element.get_event(event)

class Button(Label):
    def __init__(self, rect, text):
        super().__init__(rect, text)
        self.bgcolor = pygame.Color("grey")
        self.pressed = False

    def render(self, surface):
        surface.fill(self.bgcolor, self.rect)
        self.rendered_text = self.font.render(self.text, 1, self.font_color)
        if not self.pressed:
            color1 = pygame.Color("white")
            color2 = pygame.Color("black")
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, centery=self.rect.centery)
        else:
            color1 = pygame.Color("black")
            color2 = pygame.Color("white")
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 7, centery=self.rect.centery + 2)

        pygame.draw.rect(surface, color1, self.rect, 2)
        pygame.draw.line(surface, color2, (self.rect.right - 1, self.rect.top), (self.rect.right - 1, self.rect.bottom), 2)
        pygame.draw.line(surface, color2, (self.rect.left, self.rect.bottom - 1), (self.rect.right, self.rect.bottom - 1), 2)
        surface.blit(self.rendered_text, self.rendered_rect)

    def get_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.pressed = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.pressed = False

running = True
all_sprites = pygame.sprite.Group()
mountain_sprites = pygame.sprite.Group()
court_sprites = pygame.sprite.Group()
sky_sprites = pygame.sprite.Group()
hoop_sprites = pygame.sprite.Group()
hearts_sprites = pygame.sprite.Group()
court = Court()
Heart((0, 0))
Heart((int((width/18900)*1111) + 10, 0))
Heart((2*int((width/18900)*1111) + 20, 0))
sky = Sky()
mountain = Mountain()
hoop = Hoop()
score_sprites = pygame.sprite.Group()
position = width//2 - int((width/12600)*1679)//2
game = 1
play = 1
menu = 1
fps1 = 30
fps2 = 30
type_menu = 0
menu_gui = GUI()
game_over_gui = GUI()
type_menu_gui = GUI()
play_button = Button(((width // 2-55, height // 2 - 100),(110, 50)),'Play')
quit_button = Button(((width // 2-55, height // 2),(110, 50)), 'Quit')
menu_gui.add_element(play_button)
menu_gui.add_element(quit_button)
classic_button = Button(((width // 2-90, height // 2 - 100),(180, 50)),'Classic')
zen_button = Button(((width // 2-47, height // 2),(94, 50)),'Zen')
back_button = Button(((width // 2-60, height // 2 + 100),(120, 50)), 'Back')
type_menu_gui.add_element(classic_button)
type_menu_gui.add_element(zen_button)
type_menu_gui.add_element(back_button)
restart_button = Button(((width // 2-90, height // 2 + 50),(180, 50)),'Restart')
menu_button = Button(((width // 2-130, height // 2 + 130),(260, 50)),'Main menu')
game_over_gui.add_element(restart_button)
game_over_gui.add_element(menu_button)
classic = 0
zen = 0
clock = pygame.time.Clock()
i = 0
record = 0
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEMOTION:
            if play and game:
                if pygame.mouse.get_focused():
                    hoop.rect.x = pygame.mouse.get_pos()[0] - int((width/12600)*1679)//2
                    position = pygame.mouse.get_pos()[0] - int((width/12600)*1679)//2
            else:
                hoop.rect.x = position
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                if game:
                    play ^= 1
        if menu:
            menu_gui.get_event(event)
            if quit_button.pressed == True:
                running = False
            if play_button.pressed == True:
                menu = 0
                type_menu = 1
        elif type_menu:
            type_menu_gui.get_event(event)
            if classic_button.pressed == True:
                classic = 1
                type_menu = 0
            if zen_button.pressed == True:
                zen = 1
                type_menu = 0
            if back_button.pressed:
                menu = 1
                type_menu = 0
                play_button = Button(((width // 2-55, height // 2 - 100),(110, 50)),'Play')
                quit_button = Button(((width // 2-55, height // 2),(110, 50)), 'Quit')
                menu_gui.add_element(play_button)
                menu_gui.add_element(quit_button)
                classic_button = Button(((width // 2-90, height // 2 - 100),(180, 50)),'Classic')
                zen_button = Button(((width // 2-47, height // 2),(94, 50)),'Zen')
                back_button = Button(((width // 2-60, height // 2 + 100),(120, 50)), 'Back')
                type_menu_gui.add_element(classic_button)
                type_menu_gui.add_element(zen_button)
                type_menu_gui.add_element(back_button)                
        if not game or not play:
            game_over_gui.get_event(event)
            if restart_button.pressed:
                all_sprites = pygame.sprite.Group()
                mountain_sprites = pygame.sprite.Group()
                court_sprites = pygame.sprite.Group()
                sky_sprites = pygame.sprite.Group()
                hoop_sprites = pygame.sprite.Group()
                hearts_sprites = pygame.sprite.Group()
                court = Court()
                Heart((0, 0))
                Heart((int((width/18900)*1111) + 10, 0))
                Heart((2*int((width/18900)*1111) + 20, 0))
                sky = Sky()
                mountain = Mountain()
                hoop = Hoop()
                score_sprites = pygame.sprite.Group()
                position = width//2 - int((width/12600)*1679)//2
                game = 1
                play = 1
                menu = 0
                fps1 = 30
                fps2 = 30
                type_menu = 0
                menu_gui = GUI()
                game_over_gui = GUI()
                type_menu_gui = GUI()
                play_button = Button(((width // 2-55, height // 2 - 100),(110, 50)),'Play')
                quit_button = Button(((width // 2-55, height // 2),(110, 50)), 'Quit')
                menu_gui.add_element(play_button)
                menu_gui.add_element(quit_button)
                classic_button = Button(((width // 2-90, height // 2 - 100),(180, 50)),'Classic')
                zen_button = Button(((width // 2-47, height // 2),(94, 50)),'Zen')
                back_button = Button(((width // 2-60, height // 2 + 100),(120, 50)), 'Back')
                type_menu_gui.add_element(classic_button)
                type_menu_gui.add_element(zen_button)
                type_menu_gui.add_element(back_button) 
                restart_button = Button(((width // 2-90, height // 2 + 50),(180, 50)),'Restart')
                menu_button = Button(((width // 2-130, height // 2 + 130),(260, 50)),'Main menu')
                game_over_gui.add_element(restart_button)
                game_over_gui.add_element(menu_button)
                i = 0
            if menu_button.pressed:
                all_sprites = pygame.sprite.Group()
                mountain_sprites = pygame.sprite.Group()
                court_sprites = pygame.sprite.Group()
                sky_sprites = pygame.sprite.Group()
                hoop_sprites = pygame.sprite.Group()
                hearts_sprites = pygame.sprite.Group()
                court = Court()
                Heart((0, 0))
                Heart((int((width/18900)*1111) + 10, 0))
                Heart((2*int((width/18900)*1111) + 20, 0))
                sky = Sky()
                mountain = Mountain()
                hoop = Hoop()
                score_sprites = pygame.sprite.Group()
                position = width//2 - int((width/12600)*1679)//2
                game = 1
                play = 1
                menu = 1
                fps1 = 30
                fps2 = 30
                type_menu = 0
                menu_gui = GUI()
                game_over_gui = GUI()
                type_menu_gui = GUI()
                play_button = Button(((width // 2-55, height // 2 - 100),(110, 50)),'Play')
                quit_button = Button(((width // 2-55, height // 2),(110, 50)), 'Quit')
                menu_gui.add_element(play_button)
                menu_gui.add_element(quit_button)
                classic_button = Button(((width // 2-90, height // 2 - 100),(180, 50)),'Classic')
                zen_button = Button(((width // 2-47, height // 2),(94, 50)),'Zen')
                back_button = Button(((width // 2-60, height // 2 + 100),(120, 50)), 'Back')
                type_menu_gui.add_element(classic_button)
                type_menu_gui.add_element(zen_button)
                type_menu_gui.add_element(back_button)
                restart_button = Button(((width // 2-90, height // 2 + 50),(180, 50)),'Restart')
                menu_button = Button(((width // 2-130, height // 2 + 130),(260, 50)),'Main menu')
                game_over_gui.add_element(restart_button)
                game_over_gui.add_element(menu_button)
                classic = 0
                zen = 0
                i = 0
    if menu:
        court_sprites.draw(screen)
        menu_gui.render(screen)
        menu_gui.update()
    elif type_menu:
        court_sprites.draw(screen)
        type_menu_gui.render(screen)
        type_menu_gui.update()
    else:
        if len(hearts_sprites) == 0:
            play = 0
            game = 0
        if i % 30 == 1:
            if play:
                Landing()
                if (fps2 - 30) % 60 == 0 and (fps2 - 30) // 60 != 0 and i % fps2 == 1:
                    Heart()
        screen.fill((0,0,0))
        if play:
            all_sprites.update()
            pygame.mouse.set_visible(False)
        if zen:
            sky_sprites.draw(screen)
            mountain_sprites.draw(screen)
        if classic:
            court_sprites.draw(screen)
        hoop_sprites.draw(screen)
        all_sprites.draw(screen)
        hearts_sprites.draw(screen)
        if game:
            draw('Score: '+str(len(score_sprites)), width-100, 13, 26)
        if not play and game:
            draw('Pause', width // 2, height // 2 - 100, 50,True)
            game_over_gui.render(screen)
            game_over_gui.update()            
            pygame.mouse.set_visible(True)
        if not game:
            draw('GAME OVER', width // 2, height // 2 - 100, 50,True)
            draw('Score: '+str(len(score_sprites)), width // 2, height // 2, 30)
            record = max([len(score_sprites),record])
            draw('Record: '+str(record), width // 2, height // 2+230, 30)
            pygame.mouse.set_visible(True)
            game_over_gui.render(screen)
            game_over_gui.update()
        if play:
            i += 1
            if i == fps1:
                i = 0
                if fps1 < 150:
                    fps1 += 1
                fps2 += 1
    pygame.display.flip()
    clock.tick(fps1)
pygame.quit()